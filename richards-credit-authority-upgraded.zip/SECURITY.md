
Report vulnerabilities privately.
Emergency freezes override all permissions.
