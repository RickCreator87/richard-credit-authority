
# Richards Credit Authority

This repository defines a **tax-first, dual-approval, milestone-governed credit authority**.

## Guarantees
- Deterministic automation
- Audit-safe governance
- Cross-repo enforcement
- Emergency freeze capability

Last generated: 2026-02-08
