
def validate(authority):
    assert authority.get("max_total_credit",0) > 0
