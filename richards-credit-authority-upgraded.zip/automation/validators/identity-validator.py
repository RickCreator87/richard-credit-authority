
def validate(identity):
    assert identity.get("kyc_verified") is True
