
def validate(gov):
    assert gov.get("tax_first") is True
