
def validate(mapping):
    assert "tax-ledger" in str(mapping)
