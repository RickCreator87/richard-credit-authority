
# Deterministic cross-repo sync stub
