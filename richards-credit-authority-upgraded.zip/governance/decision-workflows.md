
1. Proposal
2. Dual-founder approval
3. Automated validation
4. Ledger commit
