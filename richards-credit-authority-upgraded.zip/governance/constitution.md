
This authority operates under tax-first, audit-first principles.
No loan may bypass tax mapping or dual approval.
