
Authority expands only after milestone verification.
