
All contributions require:
- Passing automated validation
- Dual-founder approval
- No modification of tax-first rules
